/**
  ******************************************************************************
  * @file    FHZK12GUI.H
  * @author  
  * @version 
  * @date   
  * @brief   
  ******************************************************************************

  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __FHZK12GUI_H
#define __FHZK12GUI_H

/* Includes ------------------------------------------------------------------*/
#include "GUI.h"

extern const GUI_FONT GUI_FontHZ12;


#endif /* __FHZK12GUI_H */

